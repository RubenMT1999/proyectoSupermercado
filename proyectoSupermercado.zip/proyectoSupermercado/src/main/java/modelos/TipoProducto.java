
package modelos;


public enum TipoProducto {
    ALIMENTACION,BEBIDA,DROGUERIA;
    
}
